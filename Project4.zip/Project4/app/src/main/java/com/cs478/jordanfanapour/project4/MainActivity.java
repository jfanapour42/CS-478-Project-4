package com.cs478.jordanfanapour.project4;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.GridView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;
import java.util.Set;
import java.util.TreeSet;

public class MainActivity extends AppCompatActivity {
    private final Handler mHandler = new Handler(Looper.getMainLooper()) {
        public void handleMessage(Message msg) {
            int what = msg.what ;
            switch (what) {
                case PLAYER_1_PLACE_TILE:
                    board.set(msg.arg2, R.drawable.imagex);
                    break;
                case PLAYER_1_MOVE_TILE:
                    board.set(msg.arg1, R.drawable.imageblack);
                    board.set(msg.arg2, R.drawable.imagex);
                    break;
                case PLAYER_2_PLACE_TILE:
                    board.set(msg.arg2, R.drawable.imageo);
                    break;
                case PLAYER_2_MOVE_TILE:
                    board.set(msg.arg1, R.drawable.imageblack);
                    board.set(msg.arg2, R.drawable.imageo);
                    break;
            }

            // Send messages to player threads
            int boardResult = evaluateBoard(board);
            if (boardResult != 0) {
                player1.handler.post(() -> player1.quit());
                player2.handler.post(() -> player2.quit());

                String winner;
                if (boardResult == 10) {winner = "Player 1 (X)";}
                else {winner = "Player 2 (O)";}

                Toast.makeText(MainActivity.this, winner + " won. Game Over!", Toast.LENGTH_LONG).show();
            } else {
                if (what == PLAYER_1_MOVE_TILE || what == PLAYER_1_PLACE_TILE) {
                    Message msgUpdate = player2.handler.obtainMessage(UPDATE);
                    msgUpdate.arg1 = msg.arg1;
                    msgUpdate.arg2 = msg.arg2;
                    msgUpdate.sendToTarget();
                    // send message to tell player to do their move
                    Message msgGO = player2.handler.obtainMessage(GO);
                    msgGO.sendToTarget();
                } else {
                    Message msgUpdate = player1.handler.obtainMessage(UPDATE);
                    msgUpdate.arg1 = msg.arg1;
                    msgUpdate.arg2 = msg.arg2;
                    msgUpdate.sendToTarget();
                    // send message to tell player to do their move
                    Message msgGO = player1.handler.obtainMessage(GO);
                    msgGO.sendToTarget();
                }
            }
            gridview.setAdapter(new ImageAdapter(getApplicationContext(), board));
            gridview.invalidate();
        }
    }; // Handler is associated with UI Thread

    // Values to be used by handleMessage()
    public static final int PLAYER_1_PLACE_TILE = 0 ;
    public static final int PLAYER_1_MOVE_TILE = 1 ;
    public static final int PLAYER_2_PLACE_TILE = 2 ;
    public static final int PLAYER_2_MOVE_TILE = 3 ;

    public static final int GO = 4;
    public static final int UPDATE = 5;

    private PlayerThread player1;
    private PlayerThread player2;

    private Boolean playerLock = true;
    public static final Set<Integer> allTiles = new TreeSet<>(new ArrayList<>(Arrays.asList(0, 1, 2, 3, 4, 5, 6, 7, 8)));

    private ArrayList<Integer> board = new ArrayList<>(
            Arrays.asList(R.drawable.imageblack, R.drawable.imageblack, R.drawable.imageblack,
                          R.drawable.imageblack, R.drawable.imageblack, R.drawable.imageblack,
                          R.drawable.imageblack, R.drawable.imageblack, R.drawable.imageblack));

    private GridView gridview;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Retrieve GridView declare in layout file
        gridview = findViewById(R.id.gridview);
        Button button1 =  findViewById(R.id.button1);

        // Create a new ImageAdapter and set it as the Adapter for this GridView
        gridview.setAdapter(new ImageAdapter(this, board));

        button1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Log.i("TMM Activity", "Starting New Game");
                if (player1 != null) {
                    player1.handler.removeCallbacksAndMessages(null);
                    player1.quit();
                }
                if (player2 != null) {
                    player2.handler.removeCallbacksAndMessages(null);
                    player2.quit();
                }

                player1 = new Player1Thread("Player 1");
                player2 = new Player2Thread("Player 2");
                player1.start();
                player2.start();

                mHandler.removeCallbacksAndMessages(null);

                // to ensure that UIthread will wait for on LooperPrepared to finish in
                // Player1Thread
                synchronized (playerLock) {
                    try {
                        playerLock.wait();
                    } catch (InterruptedException e) {System.out.println(e.toString());}
                    Message msg = player1.handler.obtainMessage(GO);
                    msg.sendToTarget();
                }

                board = new ArrayList<>(Arrays.asList(
                        R.drawable.imageblack, R.drawable.imageblack, R.drawable.imageblack,
                        R.drawable.imageblack, R.drawable.imageblack, R.drawable.imageblack,
                        R.drawable.imageblack, R.drawable.imageblack, R.drawable.imageblack));

                gridview.setAdapter(new ImageAdapter(getApplicationContext(), board));
                gridview.invalidate();

                Toast.makeText(MainActivity.this, "Game Starting!", Toast.LENGTH_LONG).show();
            }
        });
    }

    public abstract class PlayerThread extends HandlerThread {
        public Handler handler;
        public Set<Integer> tiles;
        public Set<Integer> opponentTiles;
        private int imageID;
        private int moveInt;
        private int placeInt;
        private String name;

        public PlayerThread(String name) {
            super(name);
            imageID = 0;
            moveInt = 0;
            placeInt = 0;
            this.name = name;
            tiles = new TreeSet<>();
            opponentTiles = new TreeSet<>();
        }

        protected void onLooperPrepared() {
            handler = new Handler(getLooper()) {
                public void handleMessage(Message msg) {
                    int what = msg.what ;
                    switch (what) {
                        case GO:
                            try {
                                Thread.sleep(2000);
                            } catch (InterruptedException e) {
                                System.out.println("Thread interrupted!");
                            }
                            // Get a message instance with target set to UI thread's message queue
                            Message pMsg;
                            if (tiles.size() < 3) {
                                int toTile = getToTilePosition();

                                pMsg = mHandler.obtainMessage(placeInt);
                                pMsg.arg1 = -1;
                                pMsg.arg2 = toTile;

                                tiles.add(toTile);
                            } else {
                                int fromTile = getFromTilePosition();
                                int toTile = getToTilePosition();

                                pMsg = mHandler.obtainMessage(moveInt);
                                pMsg.arg1 = fromTile;
                                pMsg.arg2 = toTile;

                                tiles.remove(fromTile);
                                tiles.add(toTile);
                            }
                            String str = name + " Placing tile at index " + pMsg.arg2;
                            Log.i("TMM Activity", str);
                            mHandler.sendMessage(pMsg);
                            break;
                        case UPDATE:
                            if (msg.arg1 != -1) {
                                opponentTiles.remove(msg.arg1);
                            }
                            opponentTiles.add(msg.arg2);
                            break;
                    }
                }
            };
            if (this instanceof Player1Thread) {
                // notify UIthread that onLooperPrepared finished executing
                synchronized (playerLock) {
                    playerLock.notify();
                }
            }
        }

        public void setImageID(int imageID) {
            this.imageID = imageID;
        }

        public void setMoveInt(int moveInt) {
            this.moveInt = moveInt;
        }

        public void setPlaceInt(int placeInt) {
            this.placeInt = placeInt;
        }

        public abstract int getToTilePosition();
        public abstract int getFromTilePosition();
    }

    public class Player1Thread extends PlayerThread {
        public Player1Thread(String name) {
            super(name);
            setImageID(R.drawable.imagex);
            setMoveInt(PLAYER_1_MOVE_TILE);
            setPlaceInt(PLAYER_1_PLACE_TILE);
        }

        public int getToTilePosition() {
            TreeSet<Integer> union = new TreeSet<>();
            union.addAll(tiles);
            union.addAll(opponentTiles);
            TreeSet<Integer> emptyTiles = new TreeSet<>(allTiles);
            emptyTiles.removeAll(union);

            // strategy is to pick empty tiles that are adjacent to currently placed tiles
            ArrayList<Integer> goodTiles = new ArrayList<>();
            for (int t : emptyTiles) {
                if (tiles.contains(t-1) || tiles.contains(t+1) ||
                    tiles.contains(t-3) || tiles.contains(t+3))
                {
                    goodTiles.add(t);
                }
            }

            if (goodTiles.size() > 0) {
                // return a random good tile
                Random rand = new Random();

                int num = rand.nextInt(goodTiles.size());
                return goodTiles.get(num);
            } else { // There are no goodTiles, pick middle tile if available, otherwise random
                if (emptyTiles.contains(4)) {
                    return 4;
                } else {
                    // generate a random number
                    Random rand = new Random();

                    int num = rand.nextInt(emptyTiles.size());
                    return emptyTiles.toArray(new Integer[emptyTiles.size()])[num];
                }
            }
        }

        public int getFromTilePosition() {
            // strategy is to pick an isolated tile
            ArrayList<Integer> isolatedTiles = new ArrayList<>();
            for (int t : tiles) {
                if (!(tiles.contains(t-1) || tiles.contains(t+1) ||
                        tiles.contains(t-3) || tiles.contains(t+3)))
                {
                    isolatedTiles.add(t);
                }
            }

            if (isolatedTiles.size() > 0) {
                // return a random isolated tile
                Random rand = new Random();

                int num = rand.nextInt(isolatedTiles.size());
                return isolatedTiles.get(num);
            } else {
                // return a random placed tile
                Random rand = new Random();

                int num = rand.nextInt(tiles.size());
                return tiles.toArray(new Integer[tiles.size()])[num];
            }
        }
    }

    public class Player2Thread extends PlayerThread {
        public Player2Thread(String name) {
            super(name);
            setImageID(R.drawable.imageo);
            setMoveInt(PLAYER_2_MOVE_TILE);
            setPlaceInt(PLAYER_2_PLACE_TILE);
        }

        public int getToTilePosition() {
            TreeSet<Integer> union = new TreeSet<>();
            union.addAll(tiles);
            union.addAll(opponentTiles);
            TreeSet<Integer> diff = new TreeSet<>(allTiles);
            diff.removeAll(union);

            Integer[] emptyTiles = diff.toArray(new Integer[diff.size()]);

            // generate a random number
            Random rand = new Random();

            // this will generate a random number between 0 and
            // TreeSet.size - 1
            int num = rand.nextInt(diff.size());
            int result = emptyTiles[num];

            return result;
        }

        public int getFromTilePosition() {
            Integer[] filledTiles = tiles.toArray(new Integer[tiles.size()]);
            Random rand = new Random();
            int randNum = rand.nextInt(tiles.size());
            int randPlacedTile = filledTiles[randNum];
            return randPlacedTile;
        }
    }

    //
    // Evaluates board to see if a player has won
    // If the player playing 'X' won, 10 will be returned
    // and if the player playing 'O' won, -10 will be
    // returned, otherwise returns 0
    //
    // 0 1 2
    // 3 4 5
    // 6 7 8
    //
    private int evaluateBoard(ArrayList<Integer> b) {
        // Checking rows for X or O victory
        for (int row = 0; row <= 6; row += 3) {
            if (b.get(row).equals(b.get(row + 1)) && b.get(row).equals(b.get(row + 2))) {
                if (b.get(row) == R.drawable.imagex) {
                    return 10;
                } else if (b.get(row) == R.drawable.imageo) {
                    return -10;
                }
            }
        }

        // Checking columns for X or O victory
        for (int col = 0; col <= 2; col++) {
            if (b.get(col).equals(b.get(col + 3)) &&
                    b.get(col).equals(b.get(col + 6))) {
                if (b.get(col) == R.drawable.imagex) {
                    return 10;
                } else if (b.get(col) == R.drawable.imageo) {
                    return -10;
                }
            }
        }

        return 0;
    }
}